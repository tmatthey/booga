/*
 * ActionInfoAttr.C
 *
 * Copyright (C) 1994-96, University of Berne, Switzerland
 *
 * All rights reserved.
 *
 * This software may be freely copied, modified, and redistributed
 * provided that this copyright notice is preserved on all copies.
 *
 * You may not distribute this software, in whole or in part, as part of
 * any commercial product without the express consent of the authors.
 *
 * There is no warranty or other guarantee of fitness of this software
 * for any purpose.  It is provided solely "as is".
 *
 */

#include "booga/base/Value.h"
#include "booga/base/Report.h"
#include "booga/animation/ActionInfoAttr.h"
#include "booga/animation/ActionInfo.h"

//_______________________________________________________________ ActionInfoAttr

implementRTTI(ActionInfoAttr, Makeable);

//____________________________________________________ ActionInfoAttrScaleFactor

implementRTTI(ActionInfoAttrScaleFactor, ActionInfoAttr);

ActionInfoAttrScaleFactor::ActionInfoAttrScaleFactor(const Vector3D& scaleFactor, const RCString& functionName, const Real& start, const Real& end, const Real& step)
: myScaleFactor(scaleFactor), myFunctionName(functionName), myStart(start), myEnd(end), myStep(step)
{}

Makeable* ActionInfoAttrScaleFactor::make(RCString& errMsg,
                                          const List<Value*>* parameters) const
{
  long provided_ = (!parameters ? 0 : parameters->count());
  if (provided_ < 1 || provided_ > 5) {
    extern char* form(const char * ...);
    errMsg = RCString("between 1 and 5 parameter(s) required, ")
             + form("%ld", provided_) + " provided";
    return NULL;
  }

  getParameter(1, Vector3D, scaleFactor);

  RCString functionName = "id";
  if (provided_ > 1) {
    getParameter(2, RCString, tmpVal);
    functionName = tmpVal;
  }

  Real start = 0;
  if (provided_ > 2) {
    getParameter(3, Real, tmpVal);
    start = tmpVal;
  }

  Real end = 1;
  if (provided_ > 3) {
    getParameter(4, Real, tmpVal);
    end = tmpVal;
  }

  Real step = 0;
  if (provided_ > 4) {
    getParameter(5, Real, tmpVal);
    step = tmpVal;
  }

  return new ActionInfoAttrScaleFactor(scaleFactor, functionName, start, end, step);
}

void ActionInfoAttrScaleFactor::setAttribute(ActionInfo* actioninfo) const
{
  actioninfo->setScaleFactor(myScaleFactor, myFunctionName, myStart, myEnd, myStep);
}

//________________________________________________________ ActionInfoAttrCycling

implementRTTI(ActionInfoAttrCycling, ActionInfoAttr);

ActionInfoAttrCycling::ActionInfoAttrCycling(const RCString& functionName, const Real& start, const Real& end, const Real& step)
: myFunctionName(functionName), myStart(start), myEnd(end), myStep(step)
{}

Makeable* ActionInfoAttrCycling::make(RCString& errMsg,
                                      const List<Value*>* parameters) const
{
  long provided_ = (!parameters ? 0 : parameters->count());
  if (provided_ < 0 || provided_ > 4) {
    extern char* form(const char * ...);
    errMsg = RCString("between 0 and 4 parameter(s) required, ")
             + form("%ld", provided_) + " provided";
    return NULL;
  }

  RCString functionName = "id";
  if (provided_ > 0) {
    getParameter(1, RCString, tmpVal);
    functionName = tmpVal;
  }

  Real start = 0;
  if (provided_ > 1) {
    getParameter(2, Real, tmpVal);
    start = tmpVal;
  }

  Real end = 1;
  if (provided_ > 2) {
    getParameter(3, Real, tmpVal);
    end = tmpVal;
  }

  Real step = 0;
  if (provided_ > 3) {
    getParameter(4, Real, tmpVal);
    step = tmpVal;
  }

  return new ActionInfoAttrCycling(functionName, start, end, step);
}

void ActionInfoAttrCycling::setAttribute(ActionInfo* actioninfo) const
{
  actioninfo->setCycling(myFunctionName, myStart, myEnd, myStep);
}

//_________________________________________________________ ActionInfoAttrCenter

implementRTTI(ActionInfoAttrCenter, ActionInfoAttr);

ActionInfoAttrCenter::ActionInfoAttrCenter(const Vector3D& center)
: myCenter(center)
{}

Makeable* ActionInfoAttrCenter::make(RCString& errMsg,
                                     const List<Value*>* parameters) const
{
  checkParameterNumber(1);
  getParameter(1, Vector3D, value);

  return new ActionInfoAttrCenter(value);
}

void ActionInfoAttrCenter::setAttribute(ActionInfo* actioninfo) const
{
  actioninfo->setCenter(myCenter);
}

//______________________________________________________ ActionInfoAttrDirection

implementRTTI(ActionInfoAttrDirection, ActionInfoAttr);

ActionInfoAttrDirection::ActionInfoAttrDirection(const Vector3D& direction, const RCString& functionName, const Real& start, const Real& end, const Real& step)
: myDirection(direction), myFunctionName(functionName), myStart(start), myEnd(end), myStep(step)
{}

Makeable* ActionInfoAttrDirection::make(RCString& errMsg,
                                        const List<Value*>* parameters) const
{
  long provided_ = (!parameters ? 0 : parameters->count());
  if (provided_ < 1 || provided_ > 5) {
    extern char* form(const char * ...);
    errMsg = RCString("between 1 and 5 parameter(s) required, ")
             + form("%ld", provided_) + " provided";
    return NULL;
  }

  getParameter(1, Vector3D, direction);

  RCString functionName = "id";
  if (provided_ > 1) {
    getParameter(2, RCString, tmpVal);
    functionName = tmpVal;
  }

  Real start = 0;
  if (provided_ > 2) {
    getParameter(3, Real, tmpVal);
    start = tmpVal;
  }

  Real end = 1;
  if (provided_ > 3) {
    getParameter(4, Real, tmpVal);
    end = tmpVal;
  }

  Real step = 0;
  if (provided_ > 4) {
    getParameter(5, Real, tmpVal);
    step = tmpVal;
  }

  return new ActionInfoAttrDirection(direction, functionName, start, end, step);
}

void ActionInfoAttrDirection::setAttribute(ActionInfo* actioninfo) const
{
  actioninfo->setDirection(myDirection, myFunctionName, myStart, myEnd, myStep);
}

//___________________________________________________________ ActionInfoAttrAxis

implementRTTI(ActionInfoAttrAxis, ActionInfoAttr);

ActionInfoAttrAxis::ActionInfoAttrAxis(const Vector3D& axis)
: myAxis(axis)
{}

Makeable* ActionInfoAttrAxis::make(RCString& errMsg,
                                   const List<Value*>* parameters) const
{
  checkParameterNumber(1);
  getParameter(1, Vector3D, value);

  return new ActionInfoAttrAxis(value);
}

void ActionInfoAttrAxis::setAttribute(ActionInfo* actioninfo) const
{
  actioninfo->setAxis(myAxis);
}

//__________________________________________________________ ActionInfoAttrAlpha

implementRTTI(ActionInfoAttrAlpha, ActionInfoAttr);

ActionInfoAttrAlpha::ActionInfoAttrAlpha(const Real& alpha, const RCString& functionName, const Real& start, const Real& end, const Real& step)
: myAlpha(alpha), myFunctionName(functionName), myStart(start), myEnd(end), myStep(step)
{}

Makeable* ActionInfoAttrAlpha::make(RCString& errMsg,
                                    const List<Value*>* parameters) const
{
  long provided_ = (!parameters ? 0 : parameters->count());
  if (provided_ < 1 || provided_ > 5) {
    extern char* form(const char * ...);
    errMsg = RCString("between 1 and 5 parameter(s) required, ")
             + form("%ld", provided_) + " provided";
    return NULL;
  }

  getParameter(1, Real, alpha);

  RCString functionName = "id";
  if (provided_ > 1) {
    getParameter(2, RCString, tmpVal);
    functionName = tmpVal;
  }

  Real start = 0;
  if (provided_ > 2) {
    getParameter(3, Real, tmpVal);
    start = tmpVal;
  }

  Real end = 1;
  if (provided_ > 3) {
    getParameter(4, Real, tmpVal);
    end = tmpVal;
  }

  Real step = 0;
  if (provided_ > 4) {
    getParameter(5, Real, tmpVal);
    step = tmpVal;
  }

  return new ActionInfoAttrAlpha(alpha, functionName, start, end, step);
}

void ActionInfoAttrAlpha::setAttribute(ActionInfo* actioninfo) const
{
  actioninfo->setAlpha(myAlpha, myFunctionName, myStart, myEnd, myStep);
}

//__________________________________________________________ ActionInfoAttrMorphing

implementRTTI(ActionInfoAttrMorphing, ActionInfoAttr);

ActionInfoAttrMorphing::ActionInfoAttrMorphing(const Real& alpha, const RCString& functionName, const Real& start, const Real& end, const Real& step)
: myAlpha(alpha), myFunctionName(functionName), myStart(start), myEnd(end), myStep(step)
{}

Makeable* ActionInfoAttrMorphing::make(RCString& errMsg,
                                    const List<Value*>* parameters) const
{
  long provided_ = (!parameters ? 0 : parameters->count());
  if (provided_ < 1 || provided_ > 5) {
    extern char* form(const char * ...);
    errMsg = RCString("between 1 and 5 parameter(s) required, ")
             + form("%ld", provided_) + " provided";
    return NULL;
  }

  getParameter(1, Real, alpha);

  RCString functionName = "id";
  if (provided_ > 1) {
    getParameter(2, RCString, tmpVal);
    functionName = tmpVal;
  }

  Real start = 0;
  if (provided_ > 2) {
    getParameter(3, Real, tmpVal);
    start = tmpVal;
  }

  Real end = 1;
  if (provided_ > 3) {
    getParameter(4, Real, tmpVal);
    end = tmpVal;
  }

  Real step = 0;
  if (provided_ > 4) {
    getParameter(5, Real, tmpVal);
    step = tmpVal;
  }

  return new ActionInfoAttrMorphing(alpha, functionName, start, end, step);
}

void ActionInfoAttrMorphing::setAttribute(ActionInfo* actioninfo) const
{
  actioninfo->setMorphing(myAlpha, myFunctionName, myStart, myEnd, myStep);
}

//____________________________________________________ ActionInfoAttrShearFactor

implementRTTI(ActionInfoAttrShearFactor, ActionInfoAttr);

ActionInfoAttrShearFactor::ActionInfoAttrShearFactor(const Vector2D& shearFactor, const RCString& functionName, const Real& start, const Real& end, const Real& step)
: myShearFactor(shearFactor), myFunctionName(functionName), myStart(start), myEnd(end), myStep(step)
{}

Makeable* ActionInfoAttrShearFactor::make(RCString& errMsg,
                                          const List<Value*>* parameters) const
{
  long provided_ = (!parameters ? 0 : parameters->count());
  if (provided_ < 1 || provided_ > 5) {
    extern char* form(const char * ...);
    errMsg = RCString("between 1 and 5 parameter(s) required, ")
             + form("%ld", provided_) + " provided";
    return NULL;
  }

  getParameter(1, Vector2D, shearFactor);

  RCString functionName = "id";
  if (provided_ > 1) {
    getParameter(2, RCString, tmpVal);
    functionName = tmpVal;
  }

  Real start = 0;
  if (provided_ > 2) {
    getParameter(3, Real, tmpVal);
    start = tmpVal;
  }

  Real end = 1;
  if (provided_ > 3) {
    getParameter(4, Real, tmpVal);
    end = tmpVal;
  }

  Real step = 0;
  if (provided_ > 4) {
    getParameter(5, Real, tmpVal);
    step = tmpVal;
  }

  return new ActionInfoAttrShearFactor(shearFactor, functionName, start, end, step);
}

void ActionInfoAttrShearFactor::setAttribute(ActionInfo* actioninfo) const
{
  actioninfo->setShearFactor(myShearFactor, myFunctionName, myStart, myEnd, myStep);
}

