/*
 * $RCSfile: Morph3D.C,v $
 *
 * Copyright (C) 1995-96, Thierry Matthey <matthey@iam.unibe.ch>
 *                        University of Berne, Switzerland
 *
 * All rights reserved.
 *
 * This software may be freely copied, modified, and redistributed
 * provided that this copyright notice is preserved on all copies.
 *
 * You may not distribute this software, in whole or in part, as part of
 * any commercial product without the express consent of the authors.
 *
 * There is no warranty or other guarantee of fitness of this software
 * for any purpose.  It is provided solely "as is".
 *
 * -----------------------------------------------------------------------------
 *  $Id: Morph3D.C,v 1.1 1996/11/18 15:43:26 streit Exp $
 * -----------------------------------------------------------------------------
 */

#include <strstream.h>
#include "booga/base/mathutilities.h"
#include "booga/base/Report.h"
#include "booga/base/Value.h"
#include "booga/base/Vector2D.h"
#include "booga/base/Vector3D.h"
#include "booga/base/ListUtilities.h"
#include "booga/object/List3D.h"
#include "booga/object/NullObject3D.h"
#include "booga/object/DummyMakeable.h"
#include "booga/object/MakeableHandler.h"
#include "booga/animation/ActionInfo.h"
#include "booga/animation/Morph3D.h"

// ____________________________________________________________________ Morph3D

implementRTTI(Morph3D, Animation3D);

Morph3D::Morph3D(Exemplar)
{
  myLastFactor = 0.0;
  myFrom = NULL;
  myTo = NULL;
}

Morph3D::Morph3D()
{
  myLastFactor = 0.0;
  myFrom = NULL;
  myTo = NULL;
}

Morph3D::Morph3D(const Morph3D& morph)
{
  myLastFactor = morph.myLastFactor;

  if (morph.myFrom != NULL)
    myFrom = morph.myFrom->copy();
  else
    myFrom = NULL;

  if (morph.myTo != NULL)
    myTo = morph.myTo->copy();
  else
    myTo = NULL;


}
Morph3D::~Morph3D()
{
  if(myFrom != NULL)
    delete myFrom;
  if(myTo != NULL)
    delete myTo;
}

Object3D* Morph3D::getSubobject(long index) 
{
  if (index != 0)
    Report::error("[Morph3D::getSubobject] index out of range");

  if(myAnimatedObjects == NULL)
    doFrame(myLastFactor);

  return myAnimatedObjects;
}

bool Morph3D::doFrame(Real frame)
{
  Real ticks = 0;

  if (myFrom == NULL || myTo == NULL)
    return false;
  
  cerr << "[Morph3D::doFrame] have two primimitives " << endl;

  for(long i = 0; i < myActionList.count() ; i++){
    ActionInfo* item = myActionList.item(i);
    if (item->isMorph()) {
      ticks += item->computeTicks(frame)*item->getAlpha();
    }
    else {
      ostrstream os;
      os << "[Morph3D::doFrame] action ("
         <<  item->getStartFrame() << ","
         <<  item->getEndFrame() << ") not of type Morph3D. Skip";
      Report::recoverable(os);          
    }
  }
  

  if (ticks > 1)
    ticks = 1;
  if (ticks < 0)
    ticks = 0;

  if (myTo == NULL || myFrom == NULL)
    ticks = 0;

  if (equal(myLastFactor,ticks) && myAnimatedObjects != NULL)
    return false;

  Object3D* obj = NULL;

  if (myTo == NULL){
    if(myFrom == NULL)
      obj = new NullObject3D();
    else
      obj = myFrom->copy();
  }
  else{
    if(equal(ticks,0))
      obj = myFrom->copy();
    else if(equal(ticks,1))
      obj = myTo->copy();
    else {
      cerr << "[Morph3D::doFrame] go!" << endl;
      List<Value*>* valueList = new List<Value*>;
      List<Value*>* fromList = myFrom->createParameters();
      List<Value*>* toList = myTo->createParameters();
      if(toList->count() != fromList->count()){
	obj = myFrom->copy();
	cerr << "[Morph3D::doFrame] number of parameter wnot equal." << endl;
      }
      else {

	Vector3D v3D1;
	Vector3D v3D2;
	Vector2D v2D1;
	Vector2D v2D2;
	Real     x1;
	Real     x2;
	for (long i=0; i<fromList->count(); i++){
	  cerr << "[Morph3D::doFrame] value:" << i  <<endl;
	  
	  if(fromList->item(i)->toVector3D(v3D1)>0){
	    if(toList->item(i)->toVector3D(v3D2)>0)
	      valueList->append (new Value (ticks*v3D1+(1-ticks)*v3D2));
	    else
	      valueList->append (new Value (*fromList->item(i)));	    
	  }
	  else if(fromList->item(i)->toVector2D(v2D1)>0){
	    if(toList->item(i)->toVector2D(v2D2)>0)
	      valueList->append (new Value (ticks*v2D1+(1-ticks)*v2D2));
	    else
	      valueList->append (new Value (*fromList->item(i)));	    
	  }
	  else if(fromList->item(i)->toReal(x1)>0){
	    if(toList->item(i)->toReal(x2)>0)
	      valueList->append (new Value (ticks*x1+(1-ticks)*x2));
	    else
	      valueList->append (new Value (*fromList->item(i)));	    
	  }
	  else {
	    valueList->append (new Value (*fromList->item(i)));	
	  }
	}
	cerr << "[Morph3D::doFrame] uff!" << endl;

	RCString err("Morph3D::doFrame");
	obj = dynamic_cast (Object3D,myFrom->make(err, valueList));

	if(obj == NULL)
	  obj = new NullObject3D();
      }

      cerr << "[Morph3D::doFrame] del1" << endl;
      deleteList(fromList);
      cerr << "[Morph3D::doFrame] del2" << endl;
      deleteList(toList);
      cerr << "[Morph3D::doFrame] del3" << endl;
      delete valueList;
    }
  }
  
  myLastFactor = ticks;
  if (myAnimatedObjects != NULL)
    delete myAnimatedObjects;
  myAnimatedObjects = obj;
  cerr << "[Morph3D::doFrame] Done!" << endl;

  return true;  

}

Object3D* Morph3D::copy() const
{
  return new Morph3D(*this);
}

Makeable* Morph3D::make(RCString&, const List<Value*>* ) const
{
  Morph3D* newMorph = new Morph3D(*this);

  return newMorph;
}

static const RCString MorphKeyword("morph");

RCString Morph3D::getKeyword() const 
{
  return MorphKeyword;
}

void Morph3D::iterateAttributes(MakeableHandler *handler)
{
  Object3D::iterateAttributes(handler);
  for(long i=0; i<myActionList.count(); i++)
    handler->handle(myActionList.item(i));
  
  if (myTo != NULL)
      handler->handle(myTo);
  if (myFrom != NULL)
      handler->handle(myFrom);

}

int Morph3D::setSpecifier(RCString& errMsg, Makeable* specifier)
{
  //
  // There might be an object passed, so lets try to cast
  // specifier to Object3D* :
  //
  // Take two Primitive3D of the same class.
  //
  Primitive3D* object = dynamic_cast(Primitive3D, specifier);
  if (object != NULL) {
    if (myFrom == NULL){
      myFrom = object;
      return 1;
    }
    else if (myTo == NULL && myFrom->getKeyword()==object->getKeyword()){
      myTo = object;
      return 1;
    }
  }

  // 
  // Let papa do the rest ...
  //
  return Animation3D::setSpecifier(errMsg, specifier);
}


